from django.apps import AppConfig


class DressAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dress_app'
