from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import dress
from django.core.mail import send_mail
from django.conf import settings

def home(request):
    # return HttpResponse('<h1>Home page</h1>')
    Dress = dress.objects.all()
    return render(request, 'home.html',{'dress':Dress})

def signup(request):
    return render(request, "signup.html")

def signin(request):
    return render(request, "signin.html")

def contact(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        msg = request.POST['message']

        subject = 'ContactForm'
        message = f'there is a message from {name} email {email}.The message is {msg} .Thankyou'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [settings.EMAIL_HOST_USER]
        send_mail(subject, message, email_from, recipient_list)

        subject = 'thank for submitting ContactForm'
        message = f'hi {name} ,thankyou for submitting form'
        recipient_list = [email]
        send_mail(subject, message, email_from, recipient_list)
        return render(request,"index.html")
    else:
        return render(request,"contact.html")
    