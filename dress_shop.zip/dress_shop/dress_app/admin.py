from django.contrib import admin
from .models import dress

class dressAdmin(admin.ModelAdmin):
    list_display = ('name', 'price','quantity')

admin.site.register(dress,dressAdmin)

